
require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// ✅ Serve static files from 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// ✅ Serve index.html on '/'
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ✅ Serve d1.html on '/d1'
app.get('/d1', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'd1.html'));
});

// ✅ Start the server
app.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
});
